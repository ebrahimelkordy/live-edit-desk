"use client";

import React, { useRef, useState } from "react";
import { Media, Row, IconButton } from "@once-ui-system/core";

function setByPath(obj: any, path: string, value: any) {
  const keys = path.split(".");
  let cur = obj;
  for (let i = 0; i < keys.length - 1; i++) {
    const k = keys[i];
    if (!cur[k] || typeof cur[k] !== "object") cur[k] = {};
    cur = cur[k];
  }
  cur[keys[keys.length - 1]] = value;
}

async function saveValue(path: string, value: any) {
  const payload: any = {};
  setByPath(payload, path, value);
  const res = await fetch("/api/content", {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });
  if (!res.ok) throw new Error("Save failed");
}

export function EditableImage({ path, src, alt, width, height, radius = "m" }: {
  path: string;
  src: string;
  alt: string;
  width: number | string;
  height: number | string;
  radius?: any;
}) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [currentSrc, setCurrentSrc] = useState(src);
  const [busy, setBusy] = useState(false);

  const onPick = () => inputRef.current?.click();

  const onFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      setBusy(true);
      const form = new FormData();
      form.append("file", file);
      const res = await fetch("/api/upload", { method: "POST", body: form });
      if (!res.ok) throw new Error("Upload failed");
      const { path: publicPath } = await res.json();
      await saveValue(path, publicPath);
      setCurrentSrc(publicPath);
      console.log("Image updated", publicPath);
    } catch (e) {
      console.error("Upload failed", e);
    } finally {
      setBusy(false);
      if (inputRef.current) inputRef.current.value = "";
    }
  };

  return (
    <Row position="relative">
      <Media radius={radius} sizes={typeof width === 'number' ? String(width) : width} alt={alt} src={currentSrc} />
      <Row position="absolute" top="8" right="8" gap="4">
        <IconButton size="m" variant="secondary" icon={busy ? "spinner" : "upload"} onClick={onPick} />
      </Row>
      <input ref={inputRef} type="file" accept="image/*" onChange={onFile} style={{ display: "none" }} />
    </Row>
  );
}
