"use client";

import React, { useEffect, useMemo, useState } from "react";
import { Column, Row, Heading, Text, Tag, Icon, IconButton, Button, Avatar } from "@once-ui-system/core";
import styles from "@/components/about/about.module.scss";
import { EditableText } from "@/components/admin/EditableText";
import { EditableImage } from "@/components/admin/EditableImage";

async function saveValue(path: string, value: any) {
  const setByPath = (obj: any, pathStr: string, val: any) => {
    const keys = pathStr.split(".");
    let cur = obj;
    for (let i = 0; i < keys.length - 1; i++) {
      const k = keys[i];
      if (!cur[k] || typeof cur[k] !== "object") cur[k] = {};
      cur = cur[k];
    }
    cur[keys[keys.length - 1]] = val;
  };
  const payload: any = {};
  setByPath(payload, path, value);
  await fetch("/api/content", {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });
}

export function DashboardEditor() {
  const [overrides, setOverrides] = useState<any>({});
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;
    fetch("/api/check-auth").then((r) => {
      if (!r.ok) window.location.href = "/";
    });
    const load = async () => {
      try {
        const res = await fetch("/api/content");
        if (res.ok) {
          const data = await res.json();
          if (!cancelled) setOverrides(data || {});
        }
      } catch (e) {}
      if (!cancelled) setLoading(false);
    };
    load();
    const int = setInterval(async () => {
      try {
        const res = await fetch("/api/content");
        if (res.ok) {
          const data = await res.json();
          setOverrides(data || {});
        }
      } catch (e) {}
    }, 2000);
    return () => {
      cancelled = true;
      clearInterval(int);
    };
  }, []);

  const about = useMemo(() => {
    const base = (window as any).__DEFAULT_ABOUT__ || {};
    return { ...base, ...(overrides.about || {}) };
  }, [overrides]);

  const person = useMemo(() => {
    const base = (window as any).__DEFAULT_PERSON__ || {};
    return { ...base, ...(overrides.person || {}) };
  }, [overrides]);

  const addExperience = async () => {
    const list = about.work?.experiences || [];
    const next = [...list, { company: "New Company", timeframe: "", role: "", achievements: [] }];
    await saveValue("about.work.experiences", next);
    setOverrides((o: any) => ({ ...o, about: { ...(o.about || {}), work: { ...(o.about?.work || {}), experiences: next } } }));
  };

  const removeExperience = async (index: number) => {
    const list = [...(about.work?.experiences || [])];
    list.splice(index, 1);
    await saveValue("about.work.experiences", list);
    setOverrides((o: any) => ({ ...o, about: { ...(o.about || {}), work: { ...(o.about?.work || {}), experiences: list } } }));
  };

  const addInstitution = async () => {
    const list = about.studies?.institutions || [];
    const next = [...list, { name: "New Institution", description: "" }];
    await saveValue("about.studies.institutions", next);
    setOverrides((o: any) => ({ ...o, about: { ...(o.about || {}), studies: { ...(o.about?.studies || {}), institutions: next } } }));
  };

  const removeInstitution = async (index: number) => {
    const list = [...(about.studies?.institutions || [])];
    list.splice(index, 1);
    await saveValue("about.studies.institutions", list);
    setOverrides((o: any) => ({ ...o, about: { ...(o.about || {}), studies: { ...(o.about?.studies || {}), institutions: list } } }));
  };

  const addSkill = async () => {
    const list = about.technical?.skills || [];
    const next = [...list, { title: "New Skill", description: "" }];
    await saveValue("about.technical.skills", next);
    setOverrides((o: any) => ({ ...o, about: { ...(o.about || {}), technical: { ...(o.about?.technical || {}), skills: next } } }));
  };

  const removeSkill = async (index: number) => {
    const list = [...(about.technical?.skills || [])];
    list.splice(index, 1);
    await saveValue("about.technical.skills", list);
    setOverrides((o: any) => ({ ...o, about: { ...(o.about || {}), technical: { ...(o.about?.technical || {}), skills: list } } }));
  };

  if (loading) return <Column paddingY="128">Loading editor…</Column>;

  return (
    <Column maxWidth="m">
      <Row fillWidth s={{ direction: "column" }} horizontal="center">
        {about.avatar?.display && (
          <Column
            className={styles.avatar}
            top="64"
            fitHeight
            position="sticky"
            s={{ position: "relative", style: { top: "auto" } }}
            xs={{ style: { top: "auto" } }}
            minWidth="160"
            paddingX="l"
            paddingBottom="xl"
            gap="m"
            flex={3}
            horizontal="center"
          >
            <Avatar src={person.avatar} size="xl" />
            <Row gap="8" vertical="center">
              <Icon onBackground="accent-weak" name="globe" />
              <EditableText path="person.location" value={person.location || ""} variant="body-default-s" />
            </Row>
            {person.languages && person.languages.length > 0 && (
              <Row wrap gap="8">
                {person.languages.map((language: any, index: number) => (
                  <Tag key={index} size="l">
                    {language}
                  </Tag>
                ))}
              </Row>
            )}
          </Column>
        )}

        <Column className={styles.blockAlign} flex={9} maxWidth={40}>
          <Column id={"Introduction"} fillWidth minHeight="160" vertical="center" marginBottom="32">
            <EditableText as="heading" path="person.name" value={person.name || ""} variant="display-strong-xl" />
            <EditableText path="person.role" value={person.role || ""} variant="display-default-xs" onBackground="neutral-weak" />
          </Column>

          {about.intro?.display && (
            <Column textVariant="body-default-l" fillWidth gap="m" marginBottom="xl">
              <EditableText path="about.intro.description" value={typeof about.intro?.description === "string" ? about.intro.description : ""} variant="body-default-m" onBackground="neutral-weak" placeholder="Edit introduction..." />
            </Column>
          )}

          {about.work?.display && (
            <>
              <Heading as="h2" id={about.work.title} variant="display-strong-s" marginBottom="m">
                {about.work.title}
              </Heading>
              <Row paddingBottom="8">
                <Button size="s" variant="secondary" onClick={addExperience} prefixIcon="plus" label="Add experience" />
              </Row>
              <Column fillWidth gap="l" marginBottom="40">
                {about.work.experiences?.map((experience: any, index: number) => (
                  <Column key={`${experience.company}-${experience.role}-${index}`} fillWidth>
                    <Row fillWidth horizontal="between" vertical="end" marginBottom="4">
                      <EditableText path={`about.work.experiences.${index}.company`} value={experience.company || ""} variant="heading-strong-l" />
                      <EditableText path={`about.work.experiences.${index}.timeframe`} value={experience.timeframe || ""} variant="heading-default-xs" onBackground="neutral-weak" />
                    </Row>
                    <EditableText path={`about.work.experiences.${index}.role`} value={experience.role || ""} variant="body-default-s" onBackground="brand-weak" />
                    <Column as="ul" gap="16">
                      {(experience.achievements || []).map((ach: any, aIndex: number) => (
                        <Text as="li" variant="body-default-m" key={`${experience.company}-${aIndex}`}>
                          <EditableText path={`about.work.experiences.${index}.achievements.${aIndex}`} value={typeof ach === 'string' ? ach : ''} />
                        </Text>
                      ))}
                    </Column>
                    <Row paddingTop="8" gap="8">
                      <Button size="s" variant="secondary" prefixIcon="plus" label="Add achievement" onClick={async () => {
                        const list = [...(experience.achievements || []), "New achievement"];
                        const exps = [...(about.work.experiences || [])];
                        exps[index] = { ...experience, achievements: list };
                        await saveValue("about.work.experiences", exps);
                        setOverrides((o: any) => ({ ...o, about: { ...(o.about||{}), work: { ...(o.about?.work||{}), experiences: exps } } }));
                      }} />
                      <Button size="s" variant="secondary" prefixIcon="trash" label="Remove experience" onClick={() => removeExperience(index)} />
                    </Row>
                  </Column>
                ))}
              </Column>
            </>
          )}

          {about.studies?.display && (
            <>
              <Heading as="h2" id={about.studies.title} variant="display-strong-s" marginBottom="m">{about.studies.title}</Heading>
              <Row paddingBottom="8"><Button size="s" variant="secondary" onClick={addInstitution} prefixIcon="plus" label="Add institution" /></Row>
              <Column fillWidth gap="l" marginBottom="40">
                {about.studies.institutions?.map((institution: any, index: number) => (
                  <Column key={`${institution.name}-${index}`} fillWidth gap="4">
                    <EditableText path={`about.studies.institutions.${index}.name`} value={institution.name || ""} variant="heading-strong-l" />
                    <EditableText path={`about.studies.institutions.${index}.description`} value={typeof institution.description === 'string' ? institution.description : ''} variant="heading-default-xs" onBackground="neutral-weak" />
                    <Row paddingTop="8"><Button size="s" variant="secondary" prefixIcon="trash" label="Remove" onClick={() => removeInstitution(index)} /></Row>
                  </Column>
                ))}
              </Column>
            </>
          )}

          {about.technical?.display && (
            <>
              <Heading as="h2" id={about.technical.title} variant="display-strong-s" marginBottom="40">{about.technical.title}</Heading>
              <Row paddingBottom="8"><Button size="s" variant="secondary" onClick={addSkill} prefixIcon="plus" label="Add skill" /></Row>
              <Column fillWidth gap="l">
                {about.technical.skills?.map((skill: any, index: number) => (
                  <Column key={`${skill.title}-${index}`} fillWidth gap="4">
                    <EditableText path={`about.technical.skills.${index}.title`} value={skill.title || ""} variant="heading-strong-l" />
                    <EditableText path={`about.technical.skills.${index}.description`} value={typeof skill.description === 'string' ? skill.description : ''} variant="body-default-m" onBackground="neutral-weak" />
                    <Row paddingTop="8"><Button size="s" variant="secondary" prefixIcon="trash" label="Remove" onClick={() => removeSkill(index)} /></Row>
                  </Column>
                ))}
              </Column>
            </>
          )}
        </Column>
      </Row>
    </Column>
  );
}

export default DashboardEditor;
