"use client";

import React, { useEffect, useRef, useState } from "react";
import { Textarea, Text as OnceText, Heading as OnceHeading, Row, IconButton } from "@once-ui-system/core";

function setByPath(obj: any, path: string, value: any) {
  const keys = path.split(".");
  let cur = obj;
  for (let i = 0; i < keys.length - 1; i++) {
    const k = keys[i];
    if (!cur[k] || typeof cur[k] !== "object") cur[k] = {};
    cur = cur[k];
  }
  cur[keys[keys.length - 1]] = value;
}

async function saveValue(path: string, value: any) {
  const payload: any = {};
  setByPath(payload, path, value);
  const res = await fetch("/api/content", {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });
  if (!res.ok) throw new Error("Save failed");
}

export function EditableText({
  path,
  value,
  variant = "body-default-m",
  as = "text",
  onBackground,
  placeholder,
}: {
  path: string;
  value: string;
  variant?: string;
  as?: "text" | "heading";
  onBackground?: string;
  placeholder?: string;
}) {
  const [draft, setDraft] = useState(value);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    setDraft(value);
  }, [value]);

  const handleBlur = async () => {
    if (draft === value) return;
    try {
      setSaving(true);
      await saveValue(path, draft);
      console.log("Saved", path);
    } catch (e) {
      console.error("Failed to save", e);
      setDraft(value);
    } finally {
      setSaving(false);
    }
  };

  const commonProps: any = {
    contentEditable: true,
    suppressContentEditableWarning: true,
    onInput: (e: any) => setDraft(e.currentTarget.textContent || ""),
    onBlur: handleBlur,
    style: { outline: saving ? "1px dashed var(--accent-on-background-weak)" : "none", cursor: "text" },
    'data-editable': 'true',
  };

  if (as === "heading") {
    return (
      <OnceHeading variant={variant as any} onBackground={onBackground as any} {...commonProps}>
        {draft || placeholder || ""}
      </OnceHeading>
    );
  }

  return (
    <OnceText variant={variant as any} onBackground={onBackground as any} {...commonProps}>
      {draft || placeholder || ""}
    </OnceText>
  );
}
