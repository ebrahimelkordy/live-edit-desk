"use client";

import React from "react";
import { Column } from "@once-ui-system/core";
import DashboardEditor from "@/components/admin/DashboardEditor";

export default function DashboardPage() {
  return (
    <Column maxWidth="m">
      <DashboardEditor />
    </Column>
  );
}
