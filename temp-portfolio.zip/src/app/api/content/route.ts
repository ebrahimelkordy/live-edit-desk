import { NextRequest, NextResponse } from "next/server";
import * as cookie from "cookie";
import { readOverrides, writeOverrides } from "@/utils/contentStore";

export async function GET() {
  const data = await readOverrides();
  return NextResponse.json(data, { status: 200 });
}

export async function PUT(request: NextRequest) {
  const cookieHeader = request.headers.get("cookie") || "";
  const cookies = cookie.parse(cookieHeader);
  if (cookies.authToken !== "authenticated") {
    return NextResponse.json({ message: "Unauthorized" }, { status: 401 });
  }

  const body = await request.json();
  if (!body || typeof body !== "object") {
    return NextResponse.json({ message: "Invalid payload" }, { status: 400 });
  }

  // Merge on the server to avoid accidental deletion by clients sending partial data
  const current = await readOverrides();
  const next = { ...current, ...body };
  await writeOverrides(next);
  return NextResponse.json({ success: true }, { status: 200 });
}
