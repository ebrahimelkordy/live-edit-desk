import fs from "fs/promises";
import path from "path";

const STORE_PATH = path.join(process.cwd(), "src", "resources", "content.store.json");

export type ContentOverrides = Record<string, any>;

export async function readOverrides(): Promise<ContentOverrides> {
  try {
    const buf = await fs.readFile(STORE_PATH, "utf-8");
    return JSON.parse(buf);
  } catch (e: any) {
    if (e && (e.code === "ENOENT" || e.code === "ERR_MODULE_NOT_FOUND")) {
      return {};
    }
    throw e;
  }
}

export async function writeOverrides(data: ContentOverrides): Promise<void> {
  const dir = path.dirname(STORE_PATH);
  await fs.mkdir(dir, { recursive: true });
  await fs.writeFile(STORE_PATH, JSON.stringify(data, null, 2), "utf-8");
}

export function deepMerge<T extends object, U extends object>(base: T, override: U): T & U {
  const result: any = Array.isArray(base) ? [...(base as any)] : { ...(base as any) };
  for (const [key, val] of Object.entries(override as any)) {
    if (val === undefined) continue;
    if (val && typeof val === "object" && !Array.isArray(val)) {
      const baseChild = (base as any)[key] ?? {};
      result[key] = deepMerge(baseChild, val);
    } else {
      result[key] = val as any;
    }
  }
  return result as T & U;
}
