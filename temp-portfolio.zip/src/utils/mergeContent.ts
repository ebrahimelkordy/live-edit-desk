import { About, Home, Person } from "@/types";
import { deepMerge } from "@/utils/contentStore";

export function mergePerson(base: Person, overrides: any): Person {
  if (!overrides || !overrides.person) return base;
  return deepMerge(base, overrides.person as Partial<Person>);
}

export function mergeAbout(base: About, overrides: any): About {
  if (!overrides || !overrides.about) return base;
  const out = deepMerge(base, overrides.about);
  return out as About;
}

export function mergeHome(base: Home, overrides: any): Home {
  if (!overrides || !overrides.home) return base;
  return deepMerge(base, overrides.home as Partial<Home>);
}
